package ex1;

public interface PrinterDAO {
	void print(String s);
}
